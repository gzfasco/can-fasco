---
layout: default
title: 联系 / Contact
permalink: /pages/contact.html
---
# 联系我们 / Contact
- 总部：广州市（可按你实际地址替换）
- 电话：+86 (020) 0000 0000
- 邮箱：info@gzfasco.com
- 业务合作：sales@gzfasco.com
