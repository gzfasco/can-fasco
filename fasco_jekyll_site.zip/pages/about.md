---
layout: default
title: 关于 / About
permalink: /pages/about.html
---
# 我们是谁 / About Us
FASCO（Guangzhou Foreign Airlines Service Commercial Co., Ltd.）为境外（含港澳台）航空公司在中国提供全链路商务与运行支持。
